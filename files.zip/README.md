# ⚔️ Service Manager — Tibia

Gerenciador de fechamentos semanais de service no Tibia. Controle de horas, levels e valores por cliente.

## Como usar

### 1. Subir no GitHub

```bash
# Na pasta do projeto
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/tibia-service.git
git push -u origin main
```

### 2. Deploy no Vercel

1. Acesse [vercel.com](https://vercel.com) e faça login com sua conta GitHub
2. Clique em **"Add New Project"**
3. Selecione o repositório `tibia-service`
4. Deixe todas as configurações padrão (framework = **Other**)
5. Clique em **Deploy**

Pronto — o Vercel detecta automaticamente que é um site estático.

---

## Estrutura

```
tibia-service/
├── index.html   ← página principal
├── style.css    ← estilos
├── app.js       ← lógica
└── README.md
```

## Funcionalidades

- **Meu painel**: cadastrar e editar clientes, ver métricas, copiar fechamento formatado
- **Visão do cliente**: resumo apresentável para printar/enviar
- Dados salvos no `localStorage` do navegador
